def my_function():
    print("Hello from module1")
